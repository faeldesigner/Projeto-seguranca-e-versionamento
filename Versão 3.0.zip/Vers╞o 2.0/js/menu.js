// ========================== HEADER ============================

const $logo = document.querySelectorAll('.logo')[0];
const $navBar = document.querySelectorAll('.nav-bar')[0];
window.addEventListener('scroll',toggleNavBar,false);
function toggleNavBar() {
    if (window.pageYOffset >= $logo.offsetHeight && $navBar.classList.contains('abs-pos')) {
        $navBar.classList.remove('abs-pos');
        $navBar.classList.add('fix-pos');
        $logo.classList.remove('abs-pos');
        $logo.classList.add('fix-pos');

    } else if (window.pageYOffset < 200 && $navBar.classList.contains('fix-pos')) {
        $logo.classList.remove('fix-pos');
        $navBar.classList.add('abs-pos');
        $navBar.classList.remove('fix-pos');


    }
}

// ========================== LINK EXTERNO ============================
/*
const $extLink = document.querySelectorAll('.ext-link')[0];
$extLink.addEventListener('click',openLink,false);
function openLink(){
    window.open('https://www.mediafire.com/','_blank');
}

*/
// =========================== LINK INTERNO ==========================

//const $intLink = document.querySelectorAll('.int-link')[2];
//const $transparenciaSect = document.querySelector('#transparencia');
//$intLink.addEventListener('click',scrollTosect,false);
//function scrollTosect() {
//    scroll bruto = window.scrollTo(0,$transparenciaSect.offsetTop - $navBar.offsetHeight);
//    window.scrollTo({
//        top: $transparenciaSect.offsetTop - $navBar.offsetHeight,
//        left: 0,
//        behavior: 'smooth'
//    })
//}
//

const $intLinks = document.querySelectorAll('.int-link');
const $sectIdArr = document.querySelectorAll('main section');
$intLinks.forEach(function (cur,idx) {
    cur.addEventListener('click',function() {
        window.scrollTo({
            top: $sectIdArr[idx].offsetTop - $navBar.offsetHeight,
            left: 0,
            behavior: 'smooth'
        });
    }, false);
})

const $intInicio = document.querySelectorAll('.int-inicio');
$intInicio.forEach(function (cur) {
    cur.addEventListener('click',function() {
        window.scrollTo({
            top: 0,
            left: 0,
            behavior: 'smooth'
        });
    }, false);
})

/*const $menu = document.querySelectorAll('.menu')[0];
$menu.addEventListener('click',toggleMenu, false);
var isOpen = false;
function toggleMenu() {
    if (!isOpen) {
    $navBar.classList.add('menu-opened');
    $menu.firstElementChild.classList.add('close-btn');
    isOpen = true;

    }
    else {
        $navBar.classList.remove('menu-opened');
        $menu.firstElementChild.classList.remove('close-btn');
        isOpen = false;
    }
}
*/